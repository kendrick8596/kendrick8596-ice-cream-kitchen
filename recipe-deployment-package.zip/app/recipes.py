from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from . import get_db_connection  # Assuming get_db_connection is in __init__.py or a shared module

recipes_bp = Blueprint('recipes', __name__, url_prefix='/recipes')

@recipes_bp.route('/', methods=['GET', 'POST'])
def submit_recipe():
    if request.method == 'POST':
        if 'user_id' in session:
            account_id = session['user_id']
            recipe_name = request.form['recipe_name']
            prep_time = request.form['prep_time']
            cook_time = request.form['cook_time']
            instructions = request.form['instructions']
            
            conn = get_db_connection()
            cur = conn.cursor()

            # no longer inserting into creators table directly using the logged in users account_id for creator_account_id
            cur.execute(
                "INSERT INTO recipes (recipe_name, prep_time, cook_time, instructions, creator_account_id) VALUES (%s, %s, %s, %s, %s)",
                (recipe_name, prep_time, cook_time, instructions, account_id)
            )
        

            # Commit the transaction and close the connection
            conn.commit()
            cur.close()
            conn.close()
            flash('Recipe submitted successfully!', 'success')
            return redirect(url_for('recipes.success'))
        else:
            flash('You must be logged in to submet a recipe.', 'error')
            return redirect(url_for('auth.login')) # redirect to logon
    
    return render_template('recipe_form.html')

@recipes_bp.route('/success')
def success():
    return render_template('success.html')

@recipes_bp.route('/all')
def view_all_recipes():
    if 'user_id' in session:
        account_id = session['user_id']
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT recipe_name, prep_time, cook_time, instructions FROM recipes")
        all_recipes = cur.fetchall()
        cur.close()
        conn.close()
        return render_template('all_recipes.html', recipes=all_recipes)
    else:
        return redirect(url_for('auth.login')) # redirect to login if user is not logged in
    
@recipes_bp.route('/my_recipes')
def view_my_recipes():
    if 'user_id' in session:
        account_id = session['user_id']
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT recipe_name, prep_time, cook_time, instructions FROM recipes WHERE creator_account_id = %s", (account_id,))
        my_recipes = cur.fetchall()
        cur.close()
        conn.close()
        return render_template('my_recipes.html', recipes=my_recipes)
    else:
        return redirect(url_for('auth.login')) # redirect to login if user is not logged in
